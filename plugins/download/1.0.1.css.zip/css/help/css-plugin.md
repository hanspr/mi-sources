# CSS Plugin

The css plugin provides some extra functionalities for CSS file editing.

**Key Bindings**

- `F11` Decompress CSS file
- `F12` Basic compress CSS file
