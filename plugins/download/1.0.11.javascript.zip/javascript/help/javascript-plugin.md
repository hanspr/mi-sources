# Javascript Plugin

The javascript plugin provides some extra niceties.

**Key Bindings**

- `F9` Enable - Disable jascript code formatting on save (beautify-js).
- `F10` Enable - Disable syntaxcheck (node installed is required)
- `F11` Save min version (uglyfy-js is required)
- `Save` If Syntax check is enabled. Checks sintax after save.
    - If no errors, display a Success message at the bottom
    - If there is an error. Will split the window, show the full message and place the cursor at the line mentioned by the error description
