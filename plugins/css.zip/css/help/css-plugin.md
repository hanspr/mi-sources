# CSS Plugin

The css plugin provides some extra functionalities for CSS file editing.

**Key Bindings**

- `F11` Decompress css file
- `F12` Compress CSS file
