# Syntax Files

Syntax files.

Each yaml file specifies how to detect the filetype based on file extension or headers (first line of the file).

Then there are patterns and regions linked to highlight groups which tell micro how to highlight that filetype.

# License

Because the nano syntax files are distributed under the GNU GPLv3 license, these files are also distributed under that license. See [LICENSE](LICENSE).
